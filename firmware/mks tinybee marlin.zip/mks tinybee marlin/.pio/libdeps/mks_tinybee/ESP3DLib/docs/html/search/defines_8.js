var searchData=
[
  ['page_5fnofiles_5fsize_293',['PAGE_NOFILES_SIZE',['../nofile_8h.html#af1ab057626205fe1d5dae5474f4774aa',1,'nofile.h']]]
];
