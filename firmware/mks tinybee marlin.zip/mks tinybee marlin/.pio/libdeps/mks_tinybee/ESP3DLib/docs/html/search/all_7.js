var searchData=
[
  ['get_5fclient_5fid_53',['get_client_ID',['../class_web___server.html#a25715096be77cb11a7a4899c9c83e25d',1,'Web_Server']]],
  ['getsignal_54',['getSignal',['../class_wi_fi_config.html#a9d4cb0e58c352001800e6c5f1c1a9c0b',1,'WiFiConfig']]]
];
